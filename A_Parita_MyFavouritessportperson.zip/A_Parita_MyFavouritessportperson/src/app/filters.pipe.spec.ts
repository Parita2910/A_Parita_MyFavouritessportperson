import { FiltersPipe } from './filters.pipe';

describe('FiltersPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltersPipe();
    expect(pipe).toBeTruthy();
  });
});
