import { HoverDirective } from './hover-affect.directive';

describe('HoverDirective', () => {
  it('should create an instance', () => {
    const directive = new HoverAffectDirective();
    expect(directive).toBeTruthy();
  });
});
